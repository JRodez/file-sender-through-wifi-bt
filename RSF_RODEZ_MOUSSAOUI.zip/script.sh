#!/bin/sh
echo HELLO WORLD
sleep 1
echo BYE.
sleep 1
