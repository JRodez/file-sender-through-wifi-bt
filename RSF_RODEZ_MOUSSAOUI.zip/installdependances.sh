sudo apt install python3 python3-pip bluetooth libbluetooth-dev
sudo pip3 install tqdm pybluez argparse pathlib 
